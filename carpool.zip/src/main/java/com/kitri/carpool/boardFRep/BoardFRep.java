package com.kitri.carpool.boardFRep;


import lombok.Data;

@Data
public class BoardFRep {
	private int num;
	private String writer;
	private int board_num;
	private String comment;
}